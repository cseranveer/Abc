#include<stdio.h>
#include<fcntl.h>
#include<stdlib.h>
int main(int argc,char *argv[])
{
int p;
char readbuff[15];
printf("inside hi");

p=atoi(argv[1]);
printf("fd is %d\n",p);
read(p,readbuff,11);
printf("pid from reader file file %d\n",getpid());
printf(" readbuffer is %s\n",readbuff);
return 0;
}

