#include<unistd.h>
#include<stdio.h>

void main()
{

printf("Hello from world.c");
}
