#include<stdio.h>
#include<fcntl.h>
#include<unistd.h>
#include<stdlib.h>
void  main()
{
int fd=0,i=0,w=5,var,childpid;
//char desc[10]={'\0}; 
//printf("\nhello world\n");
//fd=open("sampletest.txt",O_CREAT|O_RDWR);
write(fd,"This is a test file",19);
printf("\nFile descriptor is %d\n",fd);
char *args[]={"/home/guneet/Documents/guneet/hi.out",NULL};
int ret=fork();

switch(ret)
{

	case 0:
		printf("pid is %d",ret);
		var=10;
		exit(5);
                //sprintf(desc,"%d",fd);
	    	//int j=execvp(args[0],args);
		//printf("j is %d",j);
		break;
	default:
		childpid=wait(&w);
		break;	
		
}
if(WIFEXITED(w))
{ 
printf("TERMINATED CORRECTLY %d",WEXITSTATUS(w));
}

}
