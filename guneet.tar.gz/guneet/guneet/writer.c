#include<stdio.h>
#include<fcntl.h>
#include<unistd.h>
#include<stdlib.h>
void  main()
{
int w=5,fd,ret,childpid;
char sfd[4];
//char readbuff[15];
int p[2];
char buff[]="This is a test file";
fd=open("s.txt",O_RDWR|O_CREAT);
printf("file descriptor is %d\n",fd);
ret=fork();
if(pipe(p)<0);
{
printf("*******Error******");
}

printf("pipe is %d %d\n",p[0],p[1]);
write(p[1],"Hello World",11);
//read(p[0],readbuff,11);
//printf(" readbuffer is %s\n",readbuff);
switch(ret)
{

	case 0:
		printf("pid is %d\n",ret);
		sprintf(sfd,"%d",p[0]);
		execl("./reader","reader",sfd,NULL);
		//exit(5);
		break;
	default:
		write(fd,buff,15);
		childpid=wait(&w);
		break;	
		
}
/*if(WIFEXITED(w))
{ 
printf("TERMINATED CORRECTLY %d\n",WEXITSTATUS(w));
}
*/
}
