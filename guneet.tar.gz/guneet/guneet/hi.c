#include<stdio.h>
#include<fcntl.h>
#include<stdlib.h>
int main(int argc,char *argv[])
{
int fd;
printf("inside hi");

fd=atoi(argv[1]);
printf("fd is %d\n",fd);
printf("pid from hi file %d\n",getpid());
return 0;
}

