#include<stdio.h>
#include<fcntl.h>
#include<unistd.h>
#include<stdlib.h>
void  main()
{
int w=5,fd,ret,childpid;
char sfd[4];
char buff[]="This is a test file";
fd=open("s.txt",O_RDWR|O_CREAT);
printf("file descriptor is %d\n",fd);
ret=fork();


switch(ret)
{

	case 0:
		printf("pid is %d\n",ret);
		sprintf(sfd,"%d",fd);
		execl("./hi","hi",sfd,NULL);
		//exit(5);
		break;
	default:
		write(fd,buff,15);
		childpid=wait(&w);
		break;	
		
}
/*if(WIFEXITED(w))
{ 
printf("TERMINATED CORRECTLY %d\n",WEXITSTATUS(w));
}
*/
}
