#include"headers.h"
//#include"dec.h"

int main(int argc, char * argv[])
	{ 	int fdr,fdw,FIFOres, childpid;
		char ch;
		REQ cmd;
		RES rcmd;
 		
		printf("\nServer started ");
		char *REC_FIFO="reqfifo"; 
		char * s_FIFO ="myfifo";
		char * c_FIFO ="cfifo";
		printf("\nClient started ");
		   
		if(access(s_FIFO,F_OK)==-1)
		{
    	    // Creating the named file(FIFO)
  			
			if(mkfifo(s_FIFO, 0666)!=0)
			{
				printf("FIFO Could not be created");
				exit(EXIT_FAILURE);		
			}
		}
        printf("\nMaking Client's FIFO .");
   
		if(access(c_FIFO,F_OK)==-1)
		{
    	    // Creating the named file(FIFO)
  			
			if(mkfifo(c_FIFO, 0666)!=0)
			{
				printf("Client's own FIFO Could not be created");
				exit(EXIT_FAILURE);		
			}
		}
   
	
   	childpid=fork();

  	switch(childpid)
	{

	case 0:
		fdr = open(s_FIFO,O_RDONLY);
       		read(fdr, &cmd, sizeof(cmd));
		sleep(1);
		switch(cmd.op)
			{
				case '+':
				execl("./add","add",NULL);
				break;
				case '-':
				execl("./sub","sub",NULL);
				break;
			}
	break;
}
	fdr = open(REC_FIFO,O_RDONLY);
	read(fdr, &rcmd, sizeof(cmd));
		sleep(1);
        // Print the read string and close
        printf("Client's PID: %d\n", cmd.pid);
        printf("Client's OP is: %c\n", cmd.op);
		printf("Client's OP1 is: %d\n", cmd.op1);
		printf("Client's OP2 is: %d\n", cmd.op2);
    
    return 0;
}
