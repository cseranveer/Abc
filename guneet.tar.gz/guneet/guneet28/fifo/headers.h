#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/types.h>
#include<fcntl.h>
#include<sys/wait.h>
#include<errno.h>
#include<signal.h>
#include<sys/stat.h>
typedef struct
{
int pid;
char op;
int op1;
int op2;
}REQ;

typedef struct
{
int pid;
int result;
}RES;


