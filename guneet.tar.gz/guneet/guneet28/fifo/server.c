#include"headers.h"
//#include"dec.h"

int main(int argc, char * argv[])
	{ 	int fdr,fdw,FIFOres;
		char ch;
		REQ cmd;
		RES rcmd;
 		
		
		printf("\nServer started ");
		   
		char * s_FIFO ="myfifo";
		char * c_FIFO ="cfifo";
		printf("\nClient started ");
		   
		if(access(s_FIFO,F_OK)==-1)
		{
    	    // Creating the named file(FIFO)
  			
			if(mkfifo(s_FIFO, 0666)!=0)
			{
				printf("FIFO Could not be created");
				exit(EXIT_FAILURE);		
			}
		}
        printf("\nMaking Client's FIFO .");
   
		if(access(c_FIFO,F_OK)==-1)
		{
    	    // Creating the named file(FIFO)
  			
			if(mkfifo(c_FIFO, 0666)!=0)
			{
				printf("Client's own FIFO Could not be created");
				exit(EXIT_FAILURE);		
			}
		}
   
	
   
    while (1)
    {
        // First open in read only and read
        fdr = open(s_FIFO,O_RDONLY);
        read(fdr, &cmd, sizeof(cmd));
		sleep(1);
        // Print the read string and close
        printf("Client's PID: %d\n", cmd.pid);
        printf("Client's OP is: %c\n", cmd.op);
		printf("Client's OP1 is: %d\n", cmd.op1);
		printf("Client's OP2 is: %d\n", cmd.op2);
       //  close(fd1);
		sleep(2);
		rcmd.pid=cmd.pid;
		rcmd.result=cmd.op1+cmd.op2;
     
        // Now open in write mode and write

        fdw = open(c_FIFO,O_WRONLY);
        write(fdw, &rcmd,sizeof(&rcmd));
        //close(fd1);
    }
    return 0;
}
