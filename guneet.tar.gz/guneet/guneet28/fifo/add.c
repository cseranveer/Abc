#include"headers.h"
//#include"dec.h"

int main(int argc, char * argv[])
{
	int fdr,fdw;
	REQ cmd;
	RES rcmd;

	char * RES_FIFO ="resfifo";
	char * REC_FIFO ="recfifo";
	char * s_FIFO ="myfifo";
		
		printf("\nadd started ");
		   
		if(access(s_FIFO,F_OK)==-1)
		{
    
  		if(mkfifo(s_FIFO, 0666)!=0)
			{
				printf("FIFO Could not be created");
				exit(EXIT_FAILURE);		
			}
		}
		
	if(mkfifo(RES_FIFO, 0666)!=0)
			{
				printf("Response FIFO Could not be created");
				exit(EXIT_FAILURE);		
			}
	if(mkfifo(REC_FIFO, 0666)!=0)
			{
				printf("Receive FIFO Could not be created");
				exit(EXIT_FAILURE);		
			}
 	fdr = open(s_FIFO,O_RDONLY);
        read(fdr, &cmd, sizeof(cmd));
	sleep(1);
	rcmd.pid=cmd.pid;
	rcmd.result=cmd.op1+cmd.op2;
	printf("Result is %d",rcmd.result);
        fdw = open(RES_FIFO,O_WRONLY);
        write(fdw,&rcmd,sizeof(rcmd));
	
    
}
