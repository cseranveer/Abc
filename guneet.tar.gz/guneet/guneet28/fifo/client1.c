#include"headers.h"
//#include"dec.h"

int main(int argc, char * argv[])
	{ 	int fdw,fdr,response;
		char ch;
		REQ cmd;
		RES rcmd;
		cmd.pid=getpid();
		cmd.op='+';
		cmd.op1=40;
		cmd.op2=60;
 
		char * s_FIFO ="myfifo";
		char * c_FIFO ="cfifo";
		printf("\nClient started ");
		   
		if(access(s_FIFO,F_OK)==-1)
		{
    	    // Creating the named file(FIFO)
  			
			if(mkfifo(s_FIFO, 0666)!=0)
			{
				printf("FIFO Could not be created");
				exit(EXIT_FAILURE);		
			}
		}
        printf("\nMaking Client's FIFO .");
   
		if(access(c_FIFO,F_OK)==-1)
		{
    	    // Creating the named file(FIFO)
  			
			if(mkfifo(c_FIFO, 0666)!=0)
			{
				printf("Client's own FIFO Could not be created");
				exit(EXIT_FAILURE);		
			}
		}
   
   		 while (1)
   			 {
				// Print the write string
				printf("Client's PID: %d\n", cmd.pid);
				printf("Client's OP is: %c\n", cmd.op);
				printf("Client's OP1 is: %d\n", cmd.op1);
				printf("Client's OP2 is: %d\n", cmd.op2);
                
				sleep(1);
				// Open FIFO for write only
				fdw = open(s_FIFO, O_WRONLY);
				write(fdw, &cmd, sizeof(cmd));

				sleep(2);
    
				 //Now open in read mode and write
				
				fdr = open(c_FIFO,O_RDONLY);
			 	read(fdr,&rcmd,sizeof(rcmd));
				printf("Client's PID: %d\n", rcmd.pid);
				printf("Result is: %d\n", rcmd.result);
				
				//close(fd1);
    		}
    return 0;
}
