#include<linux/init.h>
#include<linux/module.h>


static void_exit exitFunc(void)
{
printk(KERN_INFO "Bye Kernel");

}


module_exit(exitFunc);

