#include<linux/init.h>
#include<linux/module.h>

static int_init initFunc(void)
{
printk(KERN_INFO "Hello Kernel");
return 0;
}



module_init(initFunc);


