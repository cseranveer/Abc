#include"header.h"

//#define DEBUG
int main()
{


	int cliwritefd,cpid,ret;
	COMMAND cmnd;
	char *myfifo="/home/guneet/Documents/server/myfifo";
	cmnd.op='-';
	cmnd.op1=1;
	cmnd.op2=2;
	cpid=getpid();
	cmnd.pid=cpid;

	mkfifo(myfifo,0777);
	cliwritefd=open(myfifo,O_WRONLY);

	ret=write(cliwritefd,&cmnd, sizeof(cmnd));
	printf("ret in client is %d",ret);
	//printf("%d",ret);
	close(cliwritefd);
	exit(0);

}
