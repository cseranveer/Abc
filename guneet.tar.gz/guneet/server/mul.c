#include<stdio.h>
#include<stdlib.h>

int main(int argc, char *argv[])
{
	int rfd,wfd,result;
	COMMAND cmd;

	rfd=atio(argv[0]);
	wfd=atio(argv[1]);

	if(read(rfd,&cmd,sizeof(cmd)==-1)
		printf("Error in read");	
	
	else
		{	
			result=cmd.op1*cmd.op2;
			write(wfd,&result,sizeof(result));
		}

	close(rfd);
	close(wfd);
}
