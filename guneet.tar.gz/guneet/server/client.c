#include"head.h"

//#define DEBUG
int main(int argc, char *argv[])
{


	int ifd, ofd,i,n,res,ret;
	COMMAND cmnd;
	char op;

	ifd = atoi(argv[0]);
	ofd = atoi(argv[1]);
#ifdef DEBUG
	printf("client ifd = %d , ofd = %d\n",ifd,ofd);
#endif
	printf("Enter number of operations\n");
	scanf("%d",&n);

	for(i = 0; i < 50 ; i++)
	{
		
		/*fflush(stdin);
		printf("Enter operand 1\n");
		scanf("%d",&cmnd.op1);

		printf("Enter operand 2\n");
		scanf("%d",&cmnd.op2);

		printf("Enter opeation to perform\n");
		scanf(" %c",&cmnd.op);*/
		cmnd.op='-';
		cmnd.op1=i;
		cmnd.op2=i+1;

#ifdef DEBUG
		printf("inside client op = %c, op1= %d, op2=%d\n",cmnd.op,cmnd.op1,cmnd.op2);
#endif

		ret = write(ofd,&cmnd, sizeof(COMMAND));
#ifdef DEBUG
		perror("Client command write:");
		printf("Error number %d %d\n",errno,ret);
#endif
		//		while(1)
		//		{

		sleep(1);
		//ret = read(ifd,&res,sizeof(res));
		while(read(ifd,&res,sizeof(res)) != sizeof(int));
		printf("Res of  %d %c %d = %d\n",cmnd.op1,cmnd.op,cmnd.op2,res);
		sleep(2);
		//		}


	}
	close(ifd);
	close(ofd);
	printf("Client exiting\n");
	exit(0);


}
