#include"header.h"

//#define DEBUG
int main()
{

	int clireadfd,parentpid,childpid,ret;
	COMMAND cmnd;
	char *myfifo="/home/guneet/Documents/server/myfifo";
	mkfifo(myfifo,0777);
	clireadfd=open(myfifo,O_RDONLY);
	cliwritefd=open(myfifo,O_WRONLY);

	if(clireadfd==-1)
	{
		perror("Fifo failure\n");
		return 0;
	}

	childpid=fork();
	switch(childpid)
	{

		case 0:
			printf("client started pid=%d\n",getpid());
			execl("./add",clireadfd,cliwritefd,NULL);
			break;

		case -1:
			break;

		default:
			printf("parent started");
			/*ret =read(clireadfd,&cmnd,sizeof(cmnd));
			if(read(clireadfd,&cmnd,sizeof(cmnd)) == sizeof(cmnd))
			{
			printf("Receive command client success\n");
			}
*/
			break;

	}

}
