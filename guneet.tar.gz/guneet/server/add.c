#include"head.h"

//#define DEBUG
int main(int argc, char *argv[])
{

	int ifd,ofd;
	//int res=0;
	COMMAND cmnd;
	RESULT reslt;
	char *myfifo2="/home/guneet/Documents/server/myfifo2";
	mkfifo(myfifo2,0777);
	cliwritefd=open(myfifo2,O_WRONLY);
#ifdef DEBUG
	printf("Add process pid = %d ppid = %d ifd=%d ofd=%d\n",getpid(),getppid(),ifd,ofd);
#endif
	if(argc < 2)
	{
		printf("Arguments incorrect\n");
		return 0;
	}
	ifd = atoi(argv[0]);
	ofd = atoi(argv[1]);

	if(read(ifd,&cmnd, sizeof(cmnd)) == -1)
	{
		perror("Add process READ:");
		exit(-1);
	}
	else
	{
		perror("Add process READ:");
		printf("op= %c, op1= %d op2 = %d\n",cmnd.op, cmnd.op1,cmnd.op2);


	}

	reslt.res = cmnd.op1 + cmnd.op2;
	reslt.pid=getpid();
	//write back the result into write pipe of addpipe
	write(cliwritefd,&reslt,sizeof(reslt));


close(ofd);
close(ifd);
	exit(0);
}
