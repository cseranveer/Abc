#include "head.h"

//#define DEBUG
int main()
{

	int clpipe[2], addpipe[2],subpipe[2],mulpipe[2];
	int childpid, addpid, subpid, mulpid,status,res;
	char clireadfd[2],cliwritefd[2],addreadfd[2],addwritefd[2],fret;
	COMMAND cmnd;

	if(pipe(clpipe) == -1)
	{
		perror("Client pipe creation failed\n");
		return 0;
	}

	childpid=fork();
	switch(childpid)
	{

		case 0:
			printf("client started pid=%d\n",getpid());
			sprintf(clireadfd,"%d",clpipe[0]);//read
			sprintf(cliwritefd,"%d",clpipe[1]);//write
#ifdef DEBUG
			printf("passing ifd =%s and ofd =%s to client\n",clireadfd,cliwritefd);
#endif
			execl("./client",clireadfd,cliwritefd,NULL);
			//start execl to start client process and pass childpipe file descriptors
			break;

		case -1:
			break;

		default://parent created
			while(1)
			{	
				sleep(1);
				if(read(clpipe[0],&cmnd,sizeof(cmnd)) == sizeof(cmnd))
				{
					pipe(addpipe);
					fret= fork();
#ifdef DEBUG
					printf("Receive command client success\n");
#endif
					switch(fret)
					{
						case 0:
							//write the command data to write pipe of addpipe
							write(addpipe[1],&cmnd,sizeof(cmnd));
#ifdef DEBUG
							printf("Add child started pid=%d\n",getpid());
#endif
							sprintf(addreadfd,"%d",addpipe[0]);//read
							sprintf(addwritefd,"%d",clpipe[1]);//write
							execl("./subtract",addreadfd,addwritefd,NULL);
							break;

						default:
#ifdef DEBUG
							printf("Parent waiting for op to complete\n");
#endif
							wait(&status);
#ifdef DEBUG
							system("ps");
#endif
							//	close(addpipe[0]);
							//	close(addpipe[1]);
							//return 0;
							break;
					}
				}
			}
			break;

	}

	//open pipe to client


	//block 

}
