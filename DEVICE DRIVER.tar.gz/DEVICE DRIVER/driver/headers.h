#include <linux/init.h>
#include <linux/module.h>

MODULE_LICENSE("GPL");//bears the license

