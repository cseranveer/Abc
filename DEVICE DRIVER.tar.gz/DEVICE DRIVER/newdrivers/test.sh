#! /bin/bash

if( make )

then
	read -n1 -p "make Successful.Do you want to insert driver(y/n)?"
	if [ $REPLY = 'y' ]
	then 	
	        insmod ./modules/santdd.ko
		lsmod
		read	
		dmesg
		read

	fi
	read -n1 -p "make Successful.Do you want to remove driver(y/n)?"
	if [ $REPLY = 'y' ]
	then 	
	        rmmod santdd
		lsmod
		read	
		dmesg
		read
	fi

else 
	echo "make failed"
	read
fi
