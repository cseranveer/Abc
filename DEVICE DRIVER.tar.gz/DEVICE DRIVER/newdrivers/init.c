#include "headers.h"
#include "dec.h"
//#include "fileopr.h"

int majorno;
dev_t devid;
static int __init initFunc(void)
{
	int ret;
	printk(KERN_INFO "Hello Kernel. Here we come again\n");
	majorno=MAJORNO;
	minorno=MINORNO;
	nod=NOD;
	ret = alloc_chrdev_region(&devid,minorno,nod,DEVNAME);
	if(majorno==-1)
	{
		printk(KERN_ERR "ERROR CODE:001: Device Registration Failed\n");
	goto OUT;
	}
	majorno=MAJOR(devid);
	minorno=MINOR(devid);
	printk(KERN_INFO "Major No:%d\n",majorno);
	printk(KERN_INFO "Minor No:%d\n",minorno);
	newfile();
	return 0;
OUT:
	return -1;	
}
module_init(initFunc);
