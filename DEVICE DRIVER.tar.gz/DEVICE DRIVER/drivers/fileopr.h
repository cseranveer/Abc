#ifndef FILEOPR_H
#define FILEOPR_H
struct file_operations fops=
{

	open:openDev,
	release:releaseDev
};
#endif
