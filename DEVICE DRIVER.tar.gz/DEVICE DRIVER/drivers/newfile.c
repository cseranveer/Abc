#include "headers.h"
#include "dec.h"

int newfile(void)
{

printk(KERN_INFO "Hello newfile. Here we come again\n");

return 0;

}
