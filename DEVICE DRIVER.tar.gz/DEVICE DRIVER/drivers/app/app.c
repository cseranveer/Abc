#include<stdio.h>
#include<fcntl.h>
#include<unistd.h>
int main()
{

	int fd,count;
	char ch='A';
	fd=open("node",O_WRONLY);
	if(fd==-1)
	{
		perror("error while opening");	
	}
	count=write(fd,&ch,1);
	printf("Written Bytes %d",count);
	close(fd);
	return 0;
}
