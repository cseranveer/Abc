#ifndef DEVNAME
#define DEVNAME "MyCharDD"
#endif

#ifndef MAJORNO
#define MAJORNO 0
#endif

#ifndef MINORNO
#define MINORNO 0
#endif

#ifndef NOD
#define NOD 0
#endif

typedef struct Qset
{
	struct Qset *next;
	void **data;
}Qset;

typedef struct Dev
{
	struct Qset *first;
	struct cdev c_dev;
	
}Dev;

extern Dev *dev;
extern int majorno, minorno,nod;
extern dev_t devid;

int openDev(struct inode*,struct file*);
int releaseDev(struct inode*,struct file*);

