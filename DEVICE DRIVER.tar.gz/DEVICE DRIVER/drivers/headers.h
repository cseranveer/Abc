#include <linux/init.h>
#include <linux/module.h>
#include <linux/fs.h>
#include <linux/slab.h>
#include <linux/cdev.h>
MODULE_LICENSE("GPL");//bears the license
MODULE_AUTHOR("Guneet");

