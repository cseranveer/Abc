#include "headers.h"
#include "dec.h"
//#include "fileopr.h"


int openDev(struct inode *inodep,struct file *filep)
{

	printk(KERN_INFO "I AM IN OPEN DEV\n");
	return 0;
}

