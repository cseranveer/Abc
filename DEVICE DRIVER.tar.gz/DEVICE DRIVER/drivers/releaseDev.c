#include "headers.h"
#include "dec.h"
//#include "fileopr.h"


int releaseDev(struct inode *inodep,struct file *filep)
{

	printk(KERN_INFO "I AM IN RELEASE DEV\n");
	return 0;
}

