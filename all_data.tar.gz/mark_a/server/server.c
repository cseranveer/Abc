#include <stdio.h>
#include <time.h>
#include <fcntl.h>
#include <errno.h>
#include <stdlib.h>
#include <unistd.h>
#include "../header/head.h"
#define DEBUG
int main(int argc, char *argv[])
{
#ifdef DEBUG
	printf("\nInside Server.c\n");
#endif

	COMMAND cmd;

	int addP[2], frk, ex, readDisClPipe;
	char fileDis[2], opType;
	
	// Pipe creation 
	if (pipe(addP) < 0)
	{
		printf("Pipe Creation UnSuccessfull:( ");
		exit(1);	
	}

	readDisClPipe = atoi(argv[0]);

	

	// Convert  integer to char array 
	sprintf(fileDis, "%d", addP[0]);
	

	// Forking a chile
	frk = fork();
	
	
	switch( frk )
	{
		case 0: // Child created successfully
			//Exec a process to hijack the forked process
			allocateProcessor(ex, readDisClPipe, fileDis);
			break;
		default:
		printf("\nop %c\n",cmd.op);
		printf("\nop1 %d\n",cmd.op1);
		printf("\nop2 %d\n",cmd.op2);
			write(addP[1], &cmd, sizeof(cmd));

			break;
	}

	return 0;
}
void allocateProcessor(int ex, int readDisClPipe, char *fileDis)
{
	char opType = openPacket(readDisClPipe);
	

	switch( opType )
	{
		case '+':
			printf("\n+ case\n ");
			printf("RanveerSingh%s\n", fileDis);
			ex = execl("../processors/a.out", fileDis, NULL);
			break;
		case '-':
			ex = execl("../processors/subtractor.out", fileDis, NULL);
			break;
		case '*':
			ex = execl("../processors/multiplier.out", fileDis, NULL);
			break;
	}

}
char openPacket(int readDis)
{
	COMMAND cmd;
	// Read file and extract opType 
	read(readDis, &cmd, sizeof(cmd) );
	// return opType
	//printf("\nop %c\n",cmd.op);
	//printf("\nop1 %d\n",cmd.op1);
	//printf("\nop2 %d\n",cmd.op2);
	return cmd.op;
}