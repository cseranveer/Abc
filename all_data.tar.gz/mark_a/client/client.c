#include <stdio.h>
#include <time.h>
#include <fcntl.h>
#include <errno.h>
#include <stdlib.h>
#include <unistd.h>
#include "../header/head.h"
#define DEBUG
int main()
{	

	COMMAND cmd;
	int p[2], frk, ex;
	char fileDis[2];
	cmd.op = '+';
	cmd.op1 = 1;
	cmd.op2 = 1;
	
	if (pipe(p) < 0)
	{
		printf("Pipe Creation UnSuccessfull:( ");
		exit(1);	
	}

	// Convert  integer to char array 
	sprintf(fileDis, "%d", p[0]);

	frk = fork();
	
	
	switch( frk )
	{
		case 0: // Child created successfully
			//Exec a process to hijack the forked process
						
			ex = execl("../server/a.out", fileDis, NULL);
			
			break;
		default:
			// Write to Pipe
			write(p[1],&cmd, sizeof(cmd));
			break;
	}


	return 0;
}