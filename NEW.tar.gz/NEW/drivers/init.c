#include "headers.h"
#include "dec.h"
#include "fileopr.h"

int majorno,minorno,nod;
dev_t devid;
Dev *dev;
static int __init initFunc(void)
{
	int ret;
	printk(KERN_INFO "Hello Kernel. Here we come again\n");
	majorno=MAJORNO;
	minorno=MINORNO;
	nod=NOD;
	ret = alloc_chrdev_region(&devid,minorno,nod,DEVNAME);
	if(majorno==-1)
	{
		printk(KERN_ERR "ERROR CODE:001: Device Registration Failed\n");
	goto OUT;
	}
	majorno=MAJOR(devid);
	minorno=MINOR(devid);
	printk(KERN_INFO "Major No:%d\n",majorno);
	printk(KERN_INFO "Minor No:%d\n",minorno);
	dev=kmalloc(sizeof(Dev),GFP_KERNEL);
	if(!dev)
	{
		printk(KERN_ERR "ERROR CODE:001: Device Allocation Failed\n");
		goto OUT;
	}
	cdev_init(&dev->c_dev,&fops);
	dev->c_dev.ops=&fops;
	ret=cdev_add(&dev->c_dev,devid,1);
	if(ret==-1)
	{
		printk(KERN_ERR "ERROR CODE:001: Device Allocation Failed\n");
		goto OUT;
	}
	printk(KERN_INFO "Major No:%d\n",MAJOR(dev->c_dev.dev));
	printk(KERN_INFO "Minor No:%d\n",MINOR(dev->c_dev.dev));
	return 0;
OUT:
	return -1;	
}
module_init(initFunc);
