#include "headers.h"
#include "dec.h"


static void __exit cleanupFunc(void)
{
	printk(KERN_INFO "Bye for now. We will be back\n");
	cdev_del(&dev->c_dev);
	kfree(dev);
	unregister_chrdev_region(devid,nod);
}
module_exit(cleanupFunc);
