#include "headers.h"
#include "dec.h"


static void __exit cleanupFunc(void)
{
	printk(KERN_INFO "Bye for now. We will be back\n");
	unregister_chrdev(devid,nod);
}
module_exit(cleanupFunc);
