#ifndef DEVNAME
#define DEVNAME "TestCharDD"
#endif

#ifndef MAJORNO
#define MAJORNO 0
#endif

#ifndef MINORNO
#define MINORNO 0
#endif

#ifndef NOD
#define NOD 0
#endif

extern int majorno, minorno,nod;
extern dev_t devid;
int newfile(void);
