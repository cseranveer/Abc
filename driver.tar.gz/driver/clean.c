#include <linux/init.h>
#include <linux/module.h>

static void __exit cleanupFunc(void)
{
	printk(KERN_INFO "Bye for now. We will be back\n");
}
module_exit(cleanupFunc);
