#include <linux/init.h>
#include <linux/module.h>

static int __init initFunc(void)
{
	printk(KERN_INFO "Hello Kernel. Here we come\n");
	return 0;	
}
module_init(initFunc);