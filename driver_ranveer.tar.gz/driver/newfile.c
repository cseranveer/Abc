#include "headers.h"
#include "declarations.h"

int newfile(void)
{
		printk(KERN_INFO "%sBEGIN",__func__);
		printk(KERN_INFO "%sEND",__func__);
	return 0;
}