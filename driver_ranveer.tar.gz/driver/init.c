
#include "headers.h"
#include "fileOpr.h"
#include "declarations.h"
int majorno;
dev_t devid;
Dev *dev;
static int __init initFunc(void)
{
	int ret;
	printk(KERN_INFO "Hello Kernel. Here we come\n");

	//device registratiom goes here
	majorno = MAJORNO;
	majorno = register_chrdev(majorno, DEVNAME , &fops); // returns major no 
	if(majorno == -1)
	{
		printk(KERN_ERR "ERROR CODE:001:: Device Registration Failed.\n");
		goto OUTl;
	}
	printk(KERN_INFO "Major No :%d\n", majorno);
	dev = kmalloc(sizeof(Dev), GFP_KERNEL);

	if(!dev)
	{


		printk(KERN_ERR "ERROR CODE:001:: Device Allocation Failed.\n");
			goto OUTl;
	}
	cdev_init(&dev->c_dev, &fops);
	dev->c_dev.ops= &fops;
	ret = cdev_add(&dev->c_dev, devid,1);
	if(ret == -1)
	{

		printk(KERN_ERR "ERROR CODE:001:: Device Allocation Failed.\n");
			goto OUTl;
	}


	return 0;	
OUTl:
	return -1;
}
module_init(initFunc);