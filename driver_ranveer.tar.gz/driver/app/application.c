#include<stdio.h>
#include<fcntl.h>
#include<stdlib.h>
int main()
{
	int fd, count;
	char ch = 'A';
		fd = open("node", O_WRONLY);
	if(fd == -1)
	{
		perror("open");
		return -1;
	}

	count = write(fd, &ch, 1);
	printf("Wrote %d Bytes\n", count);
	close(fd);
	return 0;
}