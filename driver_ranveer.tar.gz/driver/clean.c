#include "headers.h"
#include "declarations.h"

static void __exit cleanupFunc(void)
{
	printk(KERN_INFO "Bye for now. We will be back\n");
	cdev_del(&dev->c_dev);
	kfree(dev);
	//unrigister device driver here
	unregister_chrdev(majorno, DEVNAME);
	
}
module_exit(cleanupFunc);