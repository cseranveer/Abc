#include "headers.h"
#include "declarations.h"
//#include "fileOpr.h"

int openDev(struct inode *inodep, struct file *filrp)
{
	printk(KERN_INFO"I am OPENdev \n");
	return 0;	
}