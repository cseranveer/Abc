#ifndef DEVNAME
#define DEVNAME "MyCharDD"
#endif
#ifndef MAJORNO
#define MAJORNO 0
#endif
#ifndef MINORNO
#define MAJORNO 0
#endif
extern int majorno;
int myModule(void);

typedef struct Qset
{
	struct Qset *next;
	void **data;

} Qset;

typedef struct Dev
{
	struct Qset *first;
	struct cdev c_dev;
	

} Dev;
extern Dev *dev;

int openDev(struct inode *inodep, struct file *filrp);
int releaseDev(struct inode *inodep, struct file *filrp);