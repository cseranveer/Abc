#include "headers.h"
#include "declarations.h"
//#include "fileOpr.h"

int releaseDev(struct inode *inodep, struct file *filrp)
{
	printk(KERN_INFO"I am Release Dev \n");
	return 0;	
}